#include <Arduino.h>
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h>
#include "uart.hpp"
#include "HD44780.hpp"
#include <stdlib.h>

// Declaraciones de funciones
void moveTile(char direction);
bool isGameComplete();
void generateRandomBoard();

// Definir el tamaño del tablero
const int rows = 2;
const int cols = 5;

// Definir el arreglo que representa el tablero
char puzzleBoard[rows][cols];

// Variables para almacenar la posición de la ficha vacía
int emptyRow = 0;
int emptyCol = 0;

// Función para mover la ficha según el comando recibido por UART
void moveTile(char direction) {
    int newRow = emptyRow;
    int newCol = emptyCol;

    // Calcular la nueva posición de la ficha vacía
    switch (direction) {
        case 'S':
            newRow--;
            break;
        case 'A':
            newCol++;
            break;
        case 'W':
            newRow++;
            break;
        case 'D':
            newCol--;
            break;
    }

    // Verificar si la nueva posición está dentro de los límites del tablero
    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols) {
        // Intercambiar la posición de la ficha vacía con la posición seleccionada
        puzzleBoard[emptyRow][emptyCol] = puzzleBoard[newRow][newCol];
        puzzleBoard[newRow][newCol] = ' ';

        // Actualizar la posición de la ficha vacía
        emptyRow = newRow;
        emptyCol = newCol;
    }
}

// Función para verificar si se ha completado el juego
bool isGameComplete() {
    char expectedValue = 'A';
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            if (puzzleBoard[i][j] != ' ' && puzzleBoard[i][j] != expectedValue) {
                return false;
            }
            expectedValue++;
            if (expectedValue > 'I') {
                expectedValue = ' ';
            }
        }
    }
    return true;
}

// Función para generar una posición inicial aleatoria del tablero
void initializePuzzleBoard() {
    puzzleBoard[0][0] = 'A';
    puzzleBoard[0][1] = 'B';
    puzzleBoard[0][2] = 'C';
    puzzleBoard[0][3] = 'D';
    puzzleBoard[0][4] = 'E';

    puzzleBoard[1][0] = 'F';
    puzzleBoard[1][1] = 'G';
    puzzleBoard[1][2] = 'H';
    puzzleBoard[1][3] = ' ';
    puzzleBoard[1][4] = 'I';
    emptyRow = 1;
    emptyCol = 3;
}

void generateRandomBoard() {
    char values[] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', ' '};
    int numValues = sizeof(values) / sizeof(values[0]);

    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            int randomIndex = rand() % numValues;
            puzzleBoard[i][j] = values[randomIndex];
            if (puzzleBoard[i][j] == ' ') {
                emptyRow = i;
                emptyCol = j;
            }
            values[randomIndex] = values[numValues - 1];
            numValues--;
        }
    }
}

int main(void) {
    // Inicializar la comunicación UART
    uart_init(9600, 0);

    // Inicializar la pantalla LCD
    LCD_Initalize();

  sei();
    LCD_Clear();
    LCD_WriteText("  Puzzle Game!  ");
    _delay_ms(2000);
    LCD_Clear();

    // Generar posición inicial aleatoria del tablero
    initializePuzzleBoard();

    while (1) {
        // Verificar si hay datos disponibles en UART
        if (uart_read_count() > 0) {
            char receivedChar = uart_read();
            moveTile(receivedChar);

            // Mostrar el estado actual del tablero en la pantalla LCD
            LCD_Clear();
            for (int i = 0; i < rows; i++) {
                for (int j = 0; j < cols; j++) {
                    LCD_WriteData(puzzleBoard[i][j]);
                    LCD_WriteData(' ');
                }
                LCD_GoTo(0, i + 1);
            }

            // Verificar si se ha completado el juego
            if (isGameComplete()) {
                LCD_Clear();
                LCD_GoTo(0, 0);
                LCD_WriteText("YOU WON, PRESS TO");
                LCD_GoTo(0, 1);
                LCD_WriteText("RETRY AGAIN");

                while (uart_read_count() == 0);

                // Limpiar el tablero y reiniciar el juego
                generateRandomBoard();
                LCD_Clear();
            }
        }
    }

    return 0;
}
